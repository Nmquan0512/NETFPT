﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CuaHangDienThoai
{
    internal class DienThoai
    {
        public int MaDienThoai { get; set; }
        public string TenDienThoai { get; set; }
        public string ThuongHieu { get; set; }
    }
}
